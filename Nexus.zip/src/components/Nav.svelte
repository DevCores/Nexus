
<nav>
    <a href="/index">Main Page</a>
    <a href="/settings">Настройки</a>
</nav>